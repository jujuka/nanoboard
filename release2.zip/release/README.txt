## How to run:
1) Run the server

**Windows**:
  
double click on nanodb.exe
    
**Linux/OS X**:
  
Install mono-runtime, in command line write: 
    
    mono nanodb.exe   
    
2) Open in browser:

  http://127.0.0.1:7346   

## How to use:
  0) download captcha pack (captcha.nbc) and put it near nanodb.exe

  1) run nanodb.exe to start viewing threads in browser
  
  2) when you need to get fresh posts, click [PNG-collect]
  
  3) when you need to create container, click [PNG-create] then wait and check 'upload' folder
  
     !!! your containers folder should have at least one image before doing this
     
  4) Don't forget to keep your Places setting updated (see special thread inside Nanoboard about coordination)
  
   (you can do it after clicking [Settings],  
   
    you must run [PNG-collect] at least once for places.txt to be transfered to the config).   
    
  5) Don't forget to upload containers from 'upload' folder to some thread from Places
  
     so other people can see your posts.
