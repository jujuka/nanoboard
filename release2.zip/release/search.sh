mono Aggregator.exe
mono nbpack.exe -a http://127.0.0.1:7346 nano
